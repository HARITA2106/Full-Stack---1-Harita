# AWS Deployment with Load Balancing

## Aim

To deploy a full-stack application on AWS with load balancing and auto-scaling.

## Objectives

1. Configure AWS infrastructure using VPC, EC2 networking, ALB, ECS and security groups
2. Set up auto-scaling group / ECS service auto scaling
3. Deploy Docker containers to ECS
4. Configure Application Load Balancer
5. Implement CI/CD pipeline using GitHub Actions

## Hardware/Software Requirements

- AWS account
- AWS CLI
- Terraform 1.5+
- Docker 20.10+
- GitHub account

## About the Program

This project demonstrates production-grade deployment on AWS with high availability, load balancing and auto-scaling capabilities.

## Architecture

```text
GitHub Push
   |
   v
GitHub Actions CI/CD
   |
   v
Docker Build and Push to Amazon ECR
   |
   v
Amazon ECS Fargate Service
   |
   v
Application Load Balancer
   |
   v
Users access application through ALB DNS
```

## Expected Output

- Highly available application across 2 Availability Zones
- Load-balanced traffic using Application Load Balancer
- Auto-scaling from 2 to 4 ECS tasks based on CPU load
- Zero-downtime deployments using ECS rolling deployment
- Infrastructure as Code using Terraform

## Project Structure

```text
aws-load-balanced-ecs-deployment/
│
├── app/
│   ├── Dockerfile
│   ├── package.json
│   └── server.js
│
├── terraform/
│   ├── main.tf
│   ├── variables.tf
│   ├── outputs.tf
│   ├── provider.tf
│   └── terraform.tfvars.example
│
├── .github/
│   └── workflows/
│       └── deploy.yml
│
└── README.md
```

## Step 1: Configure AWS CLI

```bash
aws configure
```

Enter:

```text
AWS Access Key ID
AWS Secret Access Key
Region: ap-south-1
Output format: json
```

## Step 2: Create Infrastructure using Terraform

Go to terraform folder:

```bash
cd terraform
```

Copy example variables:

```bash
copy terraform.tfvars.example terraform.tfvars
```

For macOS/Linux:

```bash
cp terraform.tfvars.example terraform.tfvars
```

Initialize Terraform:

```bash
terraform init
```

Check plan:

```bash
terraform plan
```

Apply infrastructure:

```bash
terraform apply
```

Type:

```text
yes
```

## Step 3: Build Docker Image Locally

Go to app folder:

```bash
cd ../app
```

Build image:

```bash
docker build -t aws-fullstack-app .
```

Run locally:

```bash
docker run -p 8080:8080 aws-fullstack-app
```

Open:

```text
http://localhost:8080
```

## Step 4: GitHub Secrets Required

Go to:

```text
GitHub Repository → Settings → Secrets and variables → Actions
```

Add these secrets:

```text
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_REGION
ECR_REPOSITORY
ECS_CLUSTER
ECS_SERVICE
ECS_TASK_DEFINITION
CONTAINER_NAME
```

Recommended values:

```text
AWS_REGION = ap-south-1
ECR_REPOSITORY = aws-fullstack-app
ECS_CLUSTER = production-cluster
ECS_SERVICE = production-service
ECS_TASK_DEFINITION = production-task
CONTAINER_NAME = app
```

## Step 5: CI/CD Workflow

When code is pushed to the `main` branch:

1. GitHub Actions checks out the code
2. AWS credentials are configured
3. Docker image is built
4. Docker image is pushed to Amazon ECR
5. ECS task definition is updated
6. ECS service is deployed with zero downtime

## Deployment Workflow

1. `terraform apply` provisions infrastructure
2. Push code to GitHub
3. GitHub Actions builds and pushes Docker image
4. ECS pulls image from ECR
5. ALB distributes traffic across ECS tasks
6. Auto-scaling adjusts task count based on CPU load

## Terraform Destroy

To delete all AWS resources:

```bash
cd terraform
terraform destroy
```

Type:

```text
yes
```

## Learning Outcomes

After completing this experiment, students will be able to:

1. Understand AWS production deployment architecture
2. Configure VPC, public subnets, security groups and ALB
3. Deploy Docker containers on ECS Fargate
4. Implement load balancing and auto-scaling
5. Automate deployment using GitHub Actions
6. Manage infrastructure using Terraform
