const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>AWS Load Balanced App</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            display: grid;
            place-items: center;
            min-height: 100vh;
            margin: 0;
          }
          .card {
            background: white;
            padding: 40px;
            border-radius: 18px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            max-width: 800px;
            text-align: center;
          }
          h1 { color: #1e3a8a; }
          p { color: #334155; font-size: 18px; }
          .badge {
            display: inline-block;
            margin: 8px;
            background: #dbeafe;
            color: #1d4ed8;
            padding: 10px 16px;
            border-radius: 999px;
            font-weight: bold;
          }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>AWS Deployment with Load Balancing</h1>
          <p>Application running on ECS Fargate behind an Application Load Balancer.</p>
          <div>
            <span class="badge">ECS</span>
            <span class="badge">ALB</span>
            <span class="badge">Auto Scaling</span>
            <span class="badge">Terraform</span>
            <span class="badge">CI/CD</span>
          </div>
        </div>
      </body>
    </html>
  `);
});

app.get("/health", (req, res) => {
  res.status(200).json({
    status: "healthy",
    service: "aws-fullstack-demo-app",
    timestamp: new Date().toISOString()
  });
});

app.get("/api/info", (req, res) => {
  res.json({
    message: "Full-stack AWS deployment demo",
    loadBalancer: "Application Load Balancer",
    compute: "ECS Fargate",
    autoScaling: "2 to 4 tasks based on CPU"
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
