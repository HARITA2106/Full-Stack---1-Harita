output "alb_dns_name" {
  value = aws_lb.app_alb.dns_name
}

output "application_url" {
  value = "http://${aws_lb.app_alb.dns_name}"
}

output "ecr_repository_url" {
  value = aws_ecr_repository.backend.repository_url
}

output "ecs_cluster_name" {
  value = aws_ecs_cluster.main.name
}

output "ecs_service_name" {
  value = aws_ecs_service.backend.name
}
