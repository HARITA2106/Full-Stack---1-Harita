variable "aws_region" {
  type    = string
  default = "ap-south-1"
}

variable "project_name" {
  type    = string
  default = "social-media-app"
}

variable "container_port" {
  type    = number
  default = 5000
}

variable "desired_count" {
  type    = number
  default = 2
}

variable "min_capacity" {
  type    = number
  default = 2
}

variable "max_capacity" {
  type    = number
  default = 4
}

variable "mongo_uri" {
  type        = string
  description = "MongoDB Atlas or DocumentDB connection string"
  sensitive   = true
  default     = "mongodb://example:example@example.com:27017/social_media_app"
}

variable "jwt_secret" {
  type        = string
  description = "JWT secret"
  sensitive   = true
  default     = "change-this-secret"
}
