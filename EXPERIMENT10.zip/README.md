# Social Media App with AWS Deployment

## Aim
To build a social media platform with posts, authentication, and deploy on AWS.

## Objective
Build a complex real-world project that combines frontend, backend, user authentication, and cloud deployment.

## Features
- User register and login
- JWT-based authentication
- Create, edit, delete posts
- Optional image URL support
- View posts from other users in a feed
- Like and unlike posts
- Add comments
- Protected routes
- AWS deployment structure
- Docker support
- Terraform Infrastructure as Code
- GitHub Actions CI/CD workflow

## Technology Used
- React
- Node.js
- Express.js
- MongoDB for local development
- JWT
- bcryptjs
- Docker
- AWS ECS Fargate
- AWS Application Load Balancer
- AWS ECR
- Terraform
- GitHub Actions

## Project Structure

```text
social-media-aws-app/
│
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── Dockerfile
│   ├── .env.example
│   ├── middleware/
│   │   └── authMiddleware.js
│   ├── models/
│   │   ├── User.js
│   │   └── Post.js
│   └── routes/
│       ├── authRoutes.js
│       └── postRoutes.js
│
├── frontend/
│   ├── package.json
│   ├── Dockerfile
│   ├── nginx.conf
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── App.css
│       ├── api.js
│       └── pages/
│           ├── Login.jsx
│           ├── Register.jsx
│           ├── Feed.jsx
│           ├── CreatePost.jsx
│           └── Profile.jsx
│
├── terraform/
│   ├── provider.tf
│   ├── variables.tf
│   ├── main.tf
│   ├── outputs.tf
│   └── terraform.tfvars.example
│
├── .github/
│   └── workflows/
│       └── deploy.yml
│
└── docker-compose.yml
```

## Local Backend Setup

```bash
cd backend
npm install
copy .env.example .env
npm start
```

For macOS/Linux:

```bash
cp .env.example .env
npm start
```

## Local Frontend Setup

Open another terminal:

```bash
cd frontend
npm install
npm run dev
```

## Open App

```text
http://localhost:5173
```

## Local MongoDB

Make sure MongoDB is running locally.

Default database:

```text
mongodb://127.0.0.1:27017/social_media_app
```

## Docker Compose

From root folder:

```bash
docker-compose up --build
```

Frontend:

```text
http://localhost:8080
```

Backend:

```text
http://localhost:5000
```

## AWS Deployment Overview

This project includes Terraform files for deploying backend container on AWS ECS Fargate behind an Application Load Balancer.

### AWS Services Used
- VPC
- Public subnets across 2 Availability Zones
- Internet Gateway
- Application Load Balancer
- ECS Fargate
- ECR
- CloudWatch Logs
- Auto Scaling

## Terraform Deployment

```bash
cd terraform
copy terraform.tfvars.example terraform.tfvars
terraform init
terraform plan
terraform apply
```

For macOS/Linux:

```bash
cp terraform.tfvars.example terraform.tfvars
terraform init
terraform plan
terraform apply
```

## GitHub Actions Secrets

Add these secrets in your GitHub repository:

```text
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_REGION
ECR_REPOSITORY
ECS_CLUSTER
ECS_SERVICE
ECS_TASK_DEFINITION
CONTAINER_NAME
```

Recommended values:

```text
AWS_REGION=ap-south-1
ECR_REPOSITORY=social-media-backend
ECS_CLUSTER=social-media-cluster
ECS_SERVICE=social-media-service
ECS_TASK_DEFINITION=social-media-task
CONTAINER_NAME=social-media-backend
```

## Expected Output
- Fully functional social media app
- Secure login and registration
- Feed with posts from all users
- Like and comment functionality
- Scalable AWS deployment structure
- CI/CD pipeline for ECS deployment

## Note
For college/lab submission, MongoDB is used locally for easy testing. For production AWS, you can replace MongoDB with Amazon DocumentDB, MongoDB Atlas, Amazon RDS, or DynamoDB.
