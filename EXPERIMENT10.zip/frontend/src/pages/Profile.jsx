import { useEffect, useState } from 'react'
import API from '../api'

function Profile() {
  const [profile, setProfile] = useState(null)
  const [posts, setPosts] = useState([])

  useEffect(() => {
    const fetchProfile = async () => {
      const profileRes = await API.get('/auth/profile')
      const postsRes = await API.get('/posts/my-posts')
      setProfile(profileRes.data)
      setPosts(postsRes.data)
    }

    fetchProfile()
  }, [])

  if (!profile) return <div className="page">Loading...</div>

  return (
    <div className="page">
      <div className="profile-card">
        <h1>{profile.name}</h1>
        <p>{profile.email}</p>
        <p>{profile.bio}</p>
      </div>

      <h2>My Posts</h2>

      {posts.map((post) => (
        <div className="post-card" key={post._id}>
          <p>{post.caption}</p>
          {post.imageUrl && <img src={post.imageUrl} className="post-image" />}
          <small>{post.likes.length} likes • {post.comments.length} comments</small>
        </div>
      ))}
    </div>
  )
}

export default Profile
