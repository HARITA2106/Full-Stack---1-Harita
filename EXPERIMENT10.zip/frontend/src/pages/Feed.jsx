import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import API from '../api'

function Feed() {
  const [posts, setPosts] = useState([])
  const [commentText, setCommentText] = useState({})

  const user = JSON.parse(localStorage.getItem('user') || 'null')

  const fetchPosts = async () => {
    const res = await API.get('/posts')
    setPosts(res.data)
  }

  useEffect(() => {
    fetchPosts()
  }, [])

  const likePost = async (id) => {
    await API.put(`/posts/${id}/like`)
    fetchPosts()
  }

  const addComment = async (id) => {
    const text = commentText[id]
    if (!text || !text.trim()) return

    await API.post(`/posts/${id}/comments`, { text })
    setCommentText({ ...commentText, [id]: '' })
    fetchPosts()
  }

  const deletePost = async (id) => {
    if (!confirm('Delete this post?')) return
    await API.delete(`/posts/${id}`)
    fetchPosts()
  }

  return (
    <div className="page">
      <h1>Social Feed</h1>

      {posts.length === 0 && <p>No posts yet. Create your first post.</p>}

      {posts.map((post) => {
        const liked = post.likes?.includes(user?._id)
        const isOwner = post.author?._id === user?._id

        return (
          <div className="post-card" key={post._id}>
            <div className="post-header">
              <div>
                <h3>{post.author?.name}</h3>
                <small>{new Date(post.createdAt).toLocaleString()}</small>
              </div>

              {isOwner && (
                <div className="owner-actions">
                  <Link to={`/edit/${post._id}`}>Edit</Link>
                  <button onClick={() => deletePost(post._id)}>Delete</button>
                </div>
              )}
            </div>

            <p>{post.caption}</p>

            {post.imageUrl && (
              <img src={post.imageUrl} alt="post" className="post-image" />
            )}

            <div className="post-actions">
              <button onClick={() => likePost(post._id)}>
                {liked ? 'Unlike' : 'Like'} ({post.likes?.length || 0})
              </button>
            </div>

            <div className="comments">
              <h4>Comments</h4>

              {post.comments?.map((comment) => (
                <div className="comment" key={comment._id}>
                  <strong>{comment.user?.name}: </strong>
                  <span>{comment.text}</span>
                </div>
              ))}

              <div className="comment-box">
                <input
                  placeholder="Add a comment..."
                  value={commentText[post._id] || ''}
                  onChange={(e) =>
                    setCommentText({ ...commentText, [post._id]: e.target.value })
                  }
                />
                <button onClick={() => addComment(post._id)}>Comment</button>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default Feed
