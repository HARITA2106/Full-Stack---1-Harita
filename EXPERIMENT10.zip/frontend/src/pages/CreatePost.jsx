import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import API from '../api'

function CreatePost({ editMode = false }) {
  const navigate = useNavigate()
  const { id } = useParams()

  const [form, setForm] = useState({
    caption: '',
    imageUrl: ''
  })

  const [error, setError] = useState('')

  useEffect(() => {
    const loadPost = async () => {
      if (editMode && id) {
        const res = await API.get('/posts')
        const post = res.data.find((p) => p._id === id)
        if (post) {
          setForm({
            caption: post.caption,
            imageUrl: post.imageUrl || ''
          })
        }
      }
    }

    loadPost()
  }, [editMode, id])

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      if (editMode) {
        await API.put(`/posts/${id}`, form)
      } else {
        await API.post('/posts', form)
      }

      navigate('/')
    } catch (err) {
      setError(err.response?.data?.message || 'Operation failed')
    }
  }

  return (
    <div className="auth-card large-card">
      <h2>{editMode ? 'Edit Post' : 'Create Post'}</h2>

      {error && <p className="error">{error}</p>}

      <form onSubmit={handleSubmit}>
        <textarea
          name="caption"
          placeholder="What is on your mind?"
          value={form.caption}
          onChange={handleChange}
          required
          rows="6"
        ></textarea>

        <input
          name="imageUrl"
          placeholder="Optional image URL"
          value={form.imageUrl}
          onChange={handleChange}
        />

        <button type="submit">{editMode ? 'Update Post' : 'Publish Post'}</button>
      </form>
    </div>
  )
}

export default CreatePost
