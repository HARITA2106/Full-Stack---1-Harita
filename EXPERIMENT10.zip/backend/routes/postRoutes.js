const express = require("express");
const Post = require("../models/Post");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/", protect, async (req, res) => {
  const posts = await Post.find()
    .populate("author", "name email bio")
    .populate("comments.user", "name email")
    .sort({ createdAt: -1 });

  res.json(posts);
});

router.get("/my-posts", protect, async (req, res) => {
  const posts = await Post.find({ author: req.user._id })
    .populate("author", "name email bio")
    .populate("comments.user", "name email")
    .sort({ createdAt: -1 });

  res.json(posts);
});

router.post("/", protect, async (req, res) => {
  const { caption, imageUrl } = req.body;

  const post = await Post.create({
    caption,
    imageUrl,
    author: req.user._id
  });

  const populatedPost = await Post.findById(post._id)
    .populate("author", "name email bio");

  res.status(201).json(populatedPost);
});

router.put("/:id", protect, async (req, res) => {
  const post = await Post.findById(req.params.id);

  if (!post) {
    return res.status(404).json({ message: "Post not found" });
  }

  if (post.author.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: "You can edit only your own post" });
  }

  post.caption = req.body.caption || post.caption;
  post.imageUrl = req.body.imageUrl ?? post.imageUrl;

  await post.save();

  res.json(post);
});

router.delete("/:id", protect, async (req, res) => {
  const post = await Post.findById(req.params.id);

  if (!post) {
    return res.status(404).json({ message: "Post not found" });
  }

  if (post.author.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: "You can delete only your own post" });
  }

  await post.deleteOne();

  res.json({ message: "Post deleted successfully" });
});

router.put("/:id/like", protect, async (req, res) => {
  const post = await Post.findById(req.params.id);

  if (!post) {
    return res.status(404).json({ message: "Post not found" });
  }

  const alreadyLiked = post.likes.some(
    (userId) => userId.toString() === req.user._id.toString()
  );

  if (alreadyLiked) {
    post.likes = post.likes.filter(
      (userId) => userId.toString() !== req.user._id.toString()
    );
  } else {
    post.likes.push(req.user._id);
  }

  await post.save();

  const updatedPost = await Post.findById(post._id)
    .populate("author", "name email bio")
    .populate("comments.user", "name email");

  res.json(updatedPost);
});

router.post("/:id/comments", protect, async (req, res) => {
  const post = await Post.findById(req.params.id);

  if (!post) {
    return res.status(404).json({ message: "Post not found" });
  }

  post.comments.push({
    text: req.body.text,
    user: req.user._id
  });

  await post.save();

  const updatedPost = await Post.findById(post._id)
    .populate("author", "name email bio")
    .populate("comments.user", "name email");

  res.status(201).json(updatedPost);
});

module.exports = router;
