export default function App(){
 const appName = import.meta.env.VITE_APP_NAME || "Dockerized React App";
 return <div className="container"><h1>{appName}</h1><p>React app running inside Docker using multi-stage build.</p></div>
}