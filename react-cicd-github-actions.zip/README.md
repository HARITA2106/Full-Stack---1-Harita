# CI/CD Pipeline with GitHub Actions

## Aim

To implement an automated CI/CD pipeline for a React application using GitHub Actions.

## Objectives

1. Configure GitHub Actions workflow
2. Implement testing stage
3. Set up Docker build and push
4. Deploy to GitHub Packages / GitHub Container Registry
5. Add deployment notifications

## Hardware/Software Requirements

- GitHub account
- Docker Hub account or GitHub Container Registry
- Node.js 18+
- Docker 20.10+
- VS Code

## About the Program

This project demonstrates end-to-end CI/CD automation from code commit to production deployment using GitHub Actions.

The pipeline performs:

- Automated testing on pull request creation
- React production build
- Docker image build
- Docker image push to GitHub Container Registry
- Image tagging with `latest` and commit SHA
- Slack notification after successful deployment

## Project Structure

```text
react-cicd-github-actions/
│
├── .github/
│   └── workflows/
│       └── ci-cd.yml
│
├── src/
│   ├── App.jsx
│   ├── App.css
│   ├── App.test.jsx
│   ├── main.jsx
│   └── setupTests.js
│
├── Dockerfile
├── nginx.conf
├── package.json
├── vite.config.js
├── index.html
├── .dockerignore
├── .gitignore
└── README.md
```

## Local Setup

Install dependencies:

```bash
npm install
```

Run React app locally:

```bash
npm run dev
```

Run tests:

```bash
npm test
```

Build production app:

```bash
npm run build
```

## Docker Commands

Build Docker image:

```bash
docker build -t react-cicd-app .
```

Run Docker container:

```bash
docker run -p 8080:8080 react-cicd-app
```

Open in browser:

```text
http://localhost:8080
```

## GitHub Actions Setup

Create a GitHub repository and push this project.

### Required GitHub Secret

Go to:

```text
GitHub Repository → Settings → Secrets and variables → Actions → New repository secret
```

Add this secret:

```text
SLACK_WEBHOOK_URL
```

Value should be your Slack Incoming Webhook URL.

## Workflow Explanation

### 1. Pull Request Stage

When a pull request is created for the `main` branch:

- Code checkout happens
- Node.js 18 is installed
- Dependencies are installed
- Tests are executed
- React production build is created

### 2. Push to Main Stage

When code is pushed to the `main` branch:

- Tests run first
- Docker image is built
- Image is pushed to GitHub Container Registry
- Image is tagged as:
  - `latest`
  - commit SHA
- Slack notification is sent

## Expected Output

- Automated testing on PR creation
- Docker image built and pushed to GitHub Container Registry
- Slack notification on successful deployment
- Docker image tagged with:
  - `latest`
  - commit SHA

## Image Location Example

```text
ghcr.io/your-github-username/react-cicd-app:latest
ghcr.io/your-github-username/react-cicd-app:commit-sha
```

## Learning Outcomes

After completing this experiment, students will be able to:

1. Understand CI/CD pipeline concepts
2. Configure GitHub Actions workflows
3. Automate testing for React applications
4. Build and push Docker images automatically
5. Use GitHub Container Registry for deployment
6. Integrate Slack notifications in CI/CD pipelines
