import { render, screen } from '@testing-library/react'
import App from './App.jsx'

test('renders CI/CD heading', () => {
  render(<App />)
  expect(screen.getByText(/React CI\/CD Pipeline/i)).toBeInTheDocument()
})

test('renders GitHub Container Registry text', () => {
  render(<App />)
  expect(screen.getByText(/GitHub Container Registry/i)).toBeInTheDocument()
})
