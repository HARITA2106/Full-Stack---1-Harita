function App() {
  return (
    <main className="container">
      <section className="card">
        <h1>React CI/CD Pipeline</h1>
        <p>
          This React application is configured with GitHub Actions,
          automated testing, Docker build, GitHub Container Registry push,
          and Slack deployment notification.
        </p>

        <div className="features">
          <div>Testing on Pull Request</div>
          <div>Docker Multi-stage Build</div>
          <div>GitHub Container Registry</div>
          <div>Slack Deployment Notification</div>
        </div>
      </section>
    </main>
  )
}

export default App
